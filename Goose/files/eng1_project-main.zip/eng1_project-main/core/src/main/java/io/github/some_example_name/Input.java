package io.github.some_example_name;

import com.badlogic.gdx.Input.Keys;



import com.badlogic.gdx.InputAdapter;


//Saeed
public class Input extends InputAdapter {

    private final Renderer renderer;
    private final Title title;
    private final Player player;
    private final Inventory inventory;

    private final int[] hidden_event_sequence = {
        Keys.UP,
        Keys.UP,
        Keys.DOWN,
        Keys.DOWN,
        Keys.LEFT,
        Keys.RIGHT,
        Keys.LEFT,
        Keys.RIGHT,
        Keys.B,
        Keys.A
    };

    private final int[] small_event_sequence = {
        Keys.S,
        Keys.M,
        Keys.A,
        Keys.L,
        Keys.L
    };

    private int hidden_event_sequence_progress = 0;
    private int small_event_sequence_progress = 0;

    public Input(Renderer renderer, Title title, Player player, Inventory inventory) {
        this.renderer = renderer;
        this.title = title;
        this.player = player;
        this.inventory = inventory;
    }

    private void check_hidden_event_sequence_progress(int keycode) {
        if (keycode == hidden_event_sequence[hidden_event_sequence_progress]) {
            hidden_event_sequence_progress++;

            if (hidden_event_sequence_progress == hidden_event_sequence.length) {
                hidden_event_sequence_progress = 0;
                player.initialise_textures("player_glasses");
                if (player.glasses_event == false) {
                    player.glasses_event = true;
                    player.hidden_events += 1;
                }
            }
        } else {
            hidden_event_sequence_progress = (keycode == hidden_event_sequence[0]) ? 1 : 0;
        }
    }

    private void check_small_event_sequence_progress(int keycode) {
        if (keycode == small_event_sequence[small_event_sequence_progress]) {
            small_event_sequence_progress++;

            if (small_event_sequence_progress == small_event_sequence.length) {
                small_event_sequence_progress = 0;
                if (player.small_event == false) {
                    player.small_event = true;
                    player.hidden_events += 1;
                }
                player.width = 64;
                player.height = 64;
            }
        } else {
            small_event_sequence_progress = (keycode == small_event_sequence[0]) ? 1 : 0;
        }
    }


    @Override
    public boolean keyUp(int keycode) {
        switch (Main.GameState) {
            case GAMEPLAY:
                switch (keycode) {
                    case Keys.UP:
                        player.stop_up();
                        break;
                    case Keys.DOWN:
                        player.stop_down();
                        break;
                    case Keys.LEFT:
                        player.stop_left();
                        break;
                    case Keys.RIGHT:
                        player.stop_right();
                        break;
                    case Keys.SHIFT_LEFT:
                        player.running = false;
                        break;
                    case Keys.TAB:
                        Main.debug = false;
                        break;
                }
                return true;
            default:
                return false;
        }
    }

    @Override
    public boolean keyDown(int keycode) {
        check_hidden_event_sequence_progress(keycode);
        check_small_event_sequence_progress(keycode);
        switch (Main.GameState) {
            case TITLE_SCREEN:
                switch(keycode) {
                    case Keys.UP:
                        title.switch_selected_option();
                        return true;
                    case Keys.DOWN:
                        title.switch_selected_option();
                        return true;
                    case Keys.ENTER:
                        title.change_game_state();;
                        return true;
                    default:
                        return true;
                    }
            case GAMEPLAY:
                switch (keycode) {
                    case Keys.UP:
                        player.move_up();
                        break;
                    case Keys.DOWN:
                        player.move_down();
                        break;
                    case Keys.LEFT:
                        player.move_left();
                        break;
                    case Keys.RIGHT:
                        player.move_right();
                        break;
                    case Keys.SHIFT_LEFT:
                        player.running = true;
                        break;
                    case Keys.F:
                        player.interact();
                        break;
                    case Keys.TAB:
                        Main.debug = true;
                        break;
                    case Keys.I:
                        inventory.add_item("Feed Potion", 1);
                        break;
                    case Keys.J:
                        inventory.add_item("Speed Potion", 1);
                        break;
                    case Keys.NUM_1:
                        player.use_item(0);
                        break;
                    case Keys.NUM_2:
                        player.use_item(1);
                        break;
                    case Keys.NUM_3:
                        player.use_item(2);
                        break;
                    case Keys.ESCAPE:
                        Main.GameState = gamestate.TITLE_SCREEN;
                        return true;              
                    default:
                        break;
                }
                break;
            case OPTIONS:
                switch(keycode) {
                    case Keys.UP:
                        renderer.options_selection = (renderer.options_selection + 2) % 3;
                        return true;
                    case Keys.DOWN:
                        renderer.options_selection = (renderer.options_selection + 1) % 3;
                        return true;
                    case Keys.RIGHT:
                    case Keys.LEFT:
                        switch (renderer.options_selection) {
                            case 0:
                                renderer.toggle_fullscreen();
                                break;
                            case 1:
                                renderer.toggle_vsync();
                                break;
                        }
                        return true;
                    case Keys.ESCAPE:
                        Main.GameState = gamestate.TITLE_SCREEN;
                        return true;
                    case Keys.ENTER:
                        if (renderer.options_selection == 2) {
                            renderer.options_selection = 0;
                            Main.GameState = gamestate.TITLE_SCREEN;
                        }
                    default:
                        return true;
                    }
            case PAUSE:
                break;
            default:
                break;
        }

        return false;
    }
}