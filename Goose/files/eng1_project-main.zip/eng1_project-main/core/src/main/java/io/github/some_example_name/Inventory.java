
package io.github.some_example_name;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.badlogic.gdx.graphics.Texture;

//Youcef
public class Inventory {

    private static final int MAX_SLOTS = 3;
    private static final int MAX_STACK = 8;

    private final List<Item_Stack> items = new ArrayList<>();

    public Texture inventory_space;
    public Texture feed_potion;
    public Texture speed_potion;

    

    private boolean open = false;

    public Inventory() {
        inventory_space = new Texture("assets/inventory.png");
        feed_potion = new Texture("assets/cocktail.png");
        speed_potion = new Texture("assets/beer.png");
    }


    public boolean add_item(String name, int amount) {
        if (name == null || name.isEmpty() || amount <= 0) {
            return false;
        }

        for (Item_Stack item : items) {
            if (item.name.equals(name) && item.amount < MAX_STACK) {
                int space = MAX_STACK - item.amount;
                int added = Math.min(space, amount);

                item.amount += added;
                amount -= added;

                if (amount == 0) return true;
            }
        }

        while (amount > 0 && items.size() < MAX_SLOTS) {
            int stack_amount = Math.min(amount, MAX_STACK);

            items.add(new Item_Stack(name, stack_amount));
            amount -= stack_amount;
        }

        return amount == 0;
    }
    //Qian
    public boolean remove_item(String name, int amount) {
        if (name == null || amount <= 0 || get_item_count(name) < amount) {
            return false;
        }

        for (int i = 0; i < items.size(); i++) {
            Item_Stack item = items.get(i);

            if (item.name.equals(name)) {
                int removed = Math.min(item.amount, amount);

                item.amount -= removed;
                amount -= removed;

                if (item.amount == 0) {
                    items.remove(i);
                    i--;
                }

                if (amount == 0) return true;
            }
        }

        return true;
    }

    public int get_item_count(String name) {
        int count = 0;

        for (Item_Stack item : items) {
            if (item.name.equals(name)) {
                count += item.amount;
            }
        }

        return count;
    }
    //Saeed
    public List<Item_Stack> get_items() {
        return Collections.unmodifiableList(items);
    }
    //Qian
    public int get_slot_count() {
        return MAX_SLOTS;
    }
    //Qian
    public boolean is_open() {
        return open;
    }
    //Qian
    public void toggle() {
        open = !open;
    }
    //Qian
    public void close() {
        open = false;
    }
    //Yimou
    public static class Item_Stack {
        public final String name;
        public int amount;

        public Item_Stack(String name, int amount) {
            this.name = name;
            this.amount = amount;
        }
    }
}
