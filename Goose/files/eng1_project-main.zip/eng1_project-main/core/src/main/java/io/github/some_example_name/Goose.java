
package io.github.some_example_name;
import com.badlogic.gdx.graphics.Texture;

public class Goose {
    private float x;
    private float y;

    public Texture texture_goose;

    private float speed = 100f;

    private boolean active = true;

    public boolean isActive() {
        return active;
    }

    public void turnOff() {
        active = false;
    }

    public Goose(float startX, float startY) {
        this.x = startX;
        this.y = startY;
        texture_goose = new Texture("assets/duck.png");
    }

    public void update(float delta, float playerX, float playerY) {
        if (!active) {
            return;
        }
        
        float dx = playerX - x;
        float dy = playerY - y;
        

        float distance = (float) Math.sqrt(dx * dx + dy * dy);

        // Stop when close enough to the player
        if (distance > 30f) {
            float directionX = dx / distance;
            float directionY = dy / distance;

            x += directionX * speed * delta;
            y += directionY * speed * delta;
        }
    }

    public float getX() {
        return x;
    }

    public Texture get_goose_texture() {
        return texture_goose;
    }

    public float getY() {
        return y;
    }
}
