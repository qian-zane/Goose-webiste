package io.github.some_example_name;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;


//Henry
public class Player {
    public int x = 100;
    public int y = 100;
    public int width = 128;
    public int height = 128;
    private int direction = 2; //0 is north, 1 is west, 2 is south, 3 is east...
    private boolean moving = false;
    public boolean running = false;

    public int hidden_events = 0;

    public boolean glasses_event = false;
    public boolean small_event = false;

    private final Inventory inventory;
    private final Goose goose;
    public float speed_potion_timer = 0f;
    public boolean speed_potion_active = false;
    public boolean feed_potion_active = false;
    public float feed_potion_timer = 0f;
    
    private Texture texture_idle;
    private Texture texture_walk;
    private Texture texture_run;

    private Texture texture_flare;

    private float velocity_x = 0;
    private float velocity_y = 0;

    private float speed_max = 500f; //maximum movement speed
    private float acceleration = 2000f;
    private float friction = 2000f;

    private float state_delta = 0f;

    private Animation<TextureRegion>[] animation_idle;
    private Animation<TextureRegion>[] animation_walk;
    private Animation<TextureRegion>[] animation_run;

    private Animation<TextureRegion>[] animation_flare_effect;

    public Player(Inventory inventory, Goose goose) {
        this.inventory = inventory;
        this.goose = goose;
        initialise_textures("player");
    }
    //Qian
    public void use_item(int item_pos) {
        if (item_pos < 0 || item_pos >= inventory.get_items().size()) {
            return;
        }

        Inventory.Item_Stack item = inventory.get_items().get(item_pos);
        
        switch (item.name) {
            case "Speed Potion":
                if (inventory.remove_item("Speed Potion", 1)) {
                    
                    speed_potion_active = true;
                    speed_potion_timer = 30f;
                }
                break;

            case "Feed Potion":
                if (inventory.remove_item("Feed Potion", 1)) {
                    feed_potion_active = true;
                    feed_potion_timer = 30f;
                }
                break;
        }
    }

    public void interact() {
        float dx = goose.getX() - x;
        float dy = goose.getY() - y;

        if (Math.abs(dx) < 100 && Math.abs(dy) < 100) {
            goose.turnOff();
        }
    }

    @SuppressWarnings("unchecked") // not needed
    public void initialise_textures(String player_location) {
        texture_idle = new Texture("assets/" + player_location + "/standard/idle.png");
        texture_walk = new Texture("assets/" + player_location + "/standard/walk.png");
        texture_run = new Texture("assets/" + player_location + "/standard/run.png");

        texture_flare = new Texture("assets/flare.png");

        animation_idle = new Animation[4];
        animation_walk = new Animation[4];
        animation_run = new Animation[4];
        
        animation_idle = initialise_animations(texture_idle, 2, 4, 0.5f);
        animation_walk = initialise_animations(texture_walk, 8, 4, 0.12f);
        animation_run = initialise_animations(texture_run, 8, 4, 0.08f);

        animation_flare_effect = initialise_animations(texture_flare, 32, 1, 0.1f);
    }


    private Animation<TextureRegion>[] initialise_animations(
        Texture texture,
        int animation_frames,
        int animation_directions,
        float frame_duration
    ) {
        int frame_width = 64;
        int frame_height = 64;

        TextureRegion[][] frames = TextureRegion.split(
            texture,
            frame_width,
            frame_height
        );

        @SuppressWarnings("unchecked")
        Animation<TextureRegion>[] animations = new Animation[animation_directions];

        for (int row = 0; row < animation_directions; row++) {

            TextureRegion[] direction_frames = new TextureRegion[animation_frames];

            for (int column = 0; column < animation_frames; column++) {
                direction_frames[column] = frames[row][column];
            }

            animations[row] = new Animation<>(
                frame_duration,
                direction_frames
            );

            animations[row].setPlayMode(Animation.PlayMode.LOOP);
        }

        return animations;
    }
    //Henry
    public void update(float delta) {
        state_delta += delta;

        if (speed_potion_active) {
            speed_potion_timer -= delta;

            if (speed_potion_timer <= 0) {
                speed_potion_active = false;
                speed_potion_timer = 0;
            }
        }

        if (feed_potion_active) {
            feed_potion_timer -= delta;

            if (feed_potion_timer <= 0) {
                feed_potion_active = false;
                feed_potion_timer = 0;
            }
        }

        if (running) {
            acceleration = 4000f;
            speed_max = 500f;
        } else {
            acceleration = 2000f;
            speed_max = 250f;
        }

        if (speed_potion_active) {
            acceleration *= 2;
            speed_max *= 2;
        }

        if (up) {
            velocity_y += acceleration * delta;
            direction = 0;
        }

        if (down) {
            velocity_y -= acceleration * delta;
            direction = 2;
        }

        if (left) {
            velocity_x -= acceleration * delta;
            direction = 1;
        }

        if (right) {
            velocity_x += acceleration * delta;
            direction = 3;
        }

        if (!left && !right) {
            velocity_x = approach(velocity_x, 0, friction * delta);
        }

        if (!up && !down) {
            velocity_y = approach(velocity_y, 0, friction * delta);
        }


        float speed_current = (float) Math.sqrt(
            velocity_x * velocity_x + velocity_y * velocity_y
        );

        if (speed_current > speed_max) {
            velocity_x = velocity_x / speed_current * speed_max;
            velocity_y = velocity_y / speed_current * speed_max;
        }

        // Update position
        x += velocity_x * delta;
        y += velocity_y * delta;

        moving = Math.abs(velocity_x) > 1 || Math.abs(velocity_y) > 1;
    }

    private boolean up, down, left, right;

    // Input functions : Qian
    public void move_up() { up = true; }
    public void move_down() { down = true; }
    public void move_left() { left = true; }
    public void move_right() { right = true; }

    public void stop_up() { up = false; }
    public void stop_down() { down = false; }
    public void stop_left() { left = false; }
    public void stop_right() { right = false; }

    private float approach(float value, float target, float amount) {
        if (value < target) {
            return Math.min(value + amount, target);
        }
        return Math.max(value - amount, target);
    }

    public void applyFriction(float delta) {
        velocity_x = approach(velocity_x, 0, friction * delta);
        velocity_y = approach(velocity_y, 0, friction * delta);
    }

    public TextureRegion getCurrentFrame() {

        if (!moving) {
            return animation_idle[direction].getKeyFrame(state_delta);
        }

        if (running) {
            return animation_run[direction].getKeyFrame(state_delta);
        }

        return animation_walk[direction].getKeyFrame(state_delta);
    }
    //Kevin
    public TextureRegion get_feed_potion_frame() {
        return animation_flare_effect[0].getKeyFrame(state_delta);
    }
}
