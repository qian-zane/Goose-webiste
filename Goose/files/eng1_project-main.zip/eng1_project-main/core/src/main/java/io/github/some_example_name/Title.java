package io.github.some_example_name;
    //Qian
public class Title {
    public int selected_option = 0; // 0 for Play Game, 1 for Options

    public float timer = 300f;
    //Henry
    public void switch_selected_option() {
        this.selected_option = (selected_option + 1) % 2 ;
    }

    public void change_game_state() {
        switch(selected_option) {
            case 0:
                timer = 300f;
                Main.GameState = gamestate.GAMEPLAY;
                return;
            case 1:
                Main.GameState = gamestate.OPTIONS;
                return;
            default:
                System.out.println("Gamestate has fallen outside of values 0 and 1");
        }
    }
}
