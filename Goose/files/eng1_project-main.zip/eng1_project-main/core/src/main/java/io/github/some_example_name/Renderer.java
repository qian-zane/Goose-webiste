package io.github.some_example_name;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.graphics.OrthographicCamera;
//Kevin
public class Renderer implements Disposable {
    private final SpriteBatch batch;
    private final BitmapFont font;
    private final OrthographicCamera camera_game;
    private final OrthographicCamera camera_ui;

    Texture background;

    private final Title title;
    private final Player player;
    private final Inventory inventory;
    private final Goose goose;
    //private final Rounds rounds;

    private boolean FULL_SCREEN = false;
    private boolean VSYNC = false;
    

    public int options_selection = 0;
    //Yimou
    public Renderer(Title title, Player player, Rounds rounds, Inventory inventory, Goose goose) {
        this.title = title;
        this.player = player;
        //this.rounds = rounds;
        this.goose = goose;
        this.inventory = inventory;
        batch = new SpriteBatch();
        font = new BitmapFont(); // Uses LibGDX's default built-in font

        camera_game = new OrthographicCamera();
        camera_game.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        camera_ui = new OrthographicCamera();
        camera_ui.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        batch.setProjectionMatrix(camera_game.combined);
        batch.setProjectionMatrix(camera_ui.combined);

        font.getRegion().getTexture().setFilter(
            Texture.TextureFilter.Linear, 
            Texture.TextureFilter.Linear
        );
        font.getData().setScale(2.0f); // Make text larger for title screen

        create_background();
    }

    private void create_background() {
        background = new Texture("assets/back.png");
    }

    //Qian
    public void render_inventory() {
        batch.setProjectionMatrix(camera_ui.combined);

        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();

        float slotSize = 65;
        float spacing = 10;

        float x = screenWidth - slotSize - 20;

        float totalHeight = (slotSize * 3) + (spacing * 2);
        float startY = (screenHeight + totalHeight) / 2f;

        batch.begin();

        for (int i = 0; i < inventory.get_slot_count(); i++) {

            float y = startY - slotSize - i * (slotSize + spacing);

            font.setColor(Color.DARK_GRAY);
            batch.draw(
                inventory.inventory_space,
                x,
                y,
                slotSize,
                slotSize
            );

            //Slot number
            font.setColor(Color.YELLOW);
            font.draw(batch, String.valueOf(i + 1),
                x + 5,
                y + slotSize - 5
            );

            //item information
            if (i < inventory.get_items().size()) {
                Inventory.Item_Stack item = inventory.get_items().get(i);

                font.setColor(Color.WHITE);
                switch (item.name) {
                    case "Feed Potion":
                        batch.draw(inventory.feed_potion, x + 20, y + 20, slotSize - 40, slotSize - 30);
                        
                        font.draw(batch, "x" + item.amount,
                            x + slotSize - 40,
                            y + 32
                        );
                        break;
                    case "Speed Potion":
                        batch.draw(inventory.speed_potion, x + 20, y + 20, slotSize - 40, slotSize - 30);
                        
                        font.draw(batch, "x" + item.amount,
                            x + slotSize - 40,
                            y + 32
                        );
                        break;
                    default:
                        font.draw(batch, item.name,
                            x + 5,
                            y + 30
                        );

                        font.draw(batch, "x" + item.amount,
                            x + 5,
                            y + 12
                        );
                }
            }
        }

        font.setColor(Color.WHITE);

        if (player.speed_potion_active) {
            int time = (int) player.speed_potion_timer;
            font.draw(batch, String.format("Speed Potion left: %02d:%02d",
                    time / 60, time % 60), 100, 130);
        }

        if (player.feed_potion_active) {
            int time = (int) player.feed_potion_timer;
            font.draw(batch, String.format("Feed Potion left: %02d:%02d",
                    time / 60, time % 60), 100, 100);
                    player.interact();}
            
                batch.end();
}

    //Batuhan
    public void render_timer() {
        batch.setProjectionMatrix(camera_ui.combined);

        GlyphLayout layout = new GlyphLayout();

        String time = String.format(
            "%02d:%02d",
            (int) title.timer / 60,
            (int) title.timer % 60
        );

        String hiddenEvents = "Hidden Events: " + player.hidden_events + "/2";

        layout.setText(font, time);

        float x = (Gdx.graphics.getWidth() - layout.width) / 2f;
        float y = Gdx.graphics.getHeight() - 30;

        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, layout, x, y);

        layout.setText(font, hiddenEvents);
        x = (Gdx.graphics.getWidth() - layout.width) / 2f;

        font.draw(batch, layout, x, y - 30);

        batch.end();
    }
    //Kevin
    public void render_debug() {
        batch.setProjectionMatrix(camera_ui.combined);

        GlyphLayout pos = new GlyphLayout();

        String position =
            "X : " + player.x + "\n" +
            "Y : " + player.y + "\n\n" +

            "CONTROLS\n" +
            "Movement : Arrow Keys\n" +
            "Interact : F\n" +
            "Give Item : I / J\n" +
            "Use Item : 1 (Item Slot 1)\n" +
            "Run : SHIFT\n" +
            "Toggle Debug : TAB";

        pos.setText(font, position);

        float x = 10;
        float y = Gdx.graphics.getHeight() - 30;

        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, pos, x, y);
        batch.end();
    }
    //Batuhan
    public void render_background() {
        batch.setProjectionMatrix(camera_game.combined);

        batch.begin();

        batch.draw(
            background,
            100,
            100,
            2000, 2000
        );

        batch.end();
    }
    //Kevin
    public void render_goose() {
        if (!goose.isActive()) {
            return;
        }
        batch.begin();

        batch.draw(
            goose.get_goose_texture(),
            goose.getX(),
            goose.getY(),
            64,64
        );

        batch.end();
    }

    //Kevin
    public void render_player() {
        camera_game.position.set(player.x + player.width / 2, player.y + player.height / 2, 0);
        camera_game.update();

        batch.setProjectionMatrix(camera_game.combined);

        batch.begin();

        //Feed potion frame should be rendered here, needs quick fix to texture before being rendered. - Kevin

        batch.draw(
            player.getCurrentFrame(),
            player.x,
            player.y,
            player.width,
            player.height
        );

        

        batch.end();
    }


    public void render_title() {
        batch.setProjectionMatrix(camera_ui.combined);

        batch.begin();

        font.setColor(Color.WHITE);
        draw_centered("Team N", Gdx.graphics.getHeight() - 100);

        if (title.selected_option == 0) {
            font.setColor(Color.YELLOW);
            draw_centered("> Play Game", Gdx.graphics.getHeight() * 0.45f);
        } else {
            font.setColor(Color.WHITE);
            draw_centered("Play Game", Gdx.graphics.getHeight() * 0.45f);
        }

        if (title.selected_option == 1) {
            font.setColor(Color.YELLOW);
            draw_centered("> Options", Gdx.graphics.getHeight() * 0.35f);
        } else {
            font.setColor(Color.WHITE);
            draw_centered("Options", Gdx.graphics.getHeight() * 0.35f);
        }

        font.setColor(Color.WHITE);

        String text = "Hidden event activators : \n1. Typing small into the keyboard\n 2. Typing the konami code\n(UP UP DOWN DOWN LEFT RIGHT LEFT RIGHT B A)\n";
        GlyphLayout layout = new GlyphLayout();
        layout.setText(font, text);


        font.draw(batch, layout, 20, layout.height + 20);
        font.getData().setScale(1f);

        

        batch.end();
    }
    //Kevin
    public void resize_window(int width, int height) {
        camera_ui.setToOrtho(false, width, height);
        camera_ui.update();

        camera_game.setToOrtho(false, width, height);
        camera_game.update();


        batch.setProjectionMatrix(camera_game.combined);
        batch.setProjectionMatrix(camera_ui.combined);
    }

    public void toggle_vsync() {
        VSYNC = !VSYNC;
        Gdx.graphics.setVSync(VSYNC);
        System.out.println("V-Sync: " + VSYNC);
    }
    //Qian
    public void toggle_fullscreen() {
        FULL_SCREEN = !FULL_SCREEN;

        if (FULL_SCREEN) {
        Gdx.graphics.setFullscreenMode(
            Gdx.graphics.getDisplayMode()
        );
        } else {
            Gdx.graphics.setWindowedMode(640, 480);
        }

        resize_window(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        System.out.println("Fullscreen: " + FULL_SCREEN);
    }
    //Batuhan
    public void render_options() {
        batch.begin();

        font.setColor(Color.WHITE);
        draw_centered("Options", Gdx.graphics.getHeight() * 0.85f);

        String fullscreen = "Full Screen??: " + (FULL_SCREEN ? "ON" : "OFF");
        String vsync = "V-Sync??: " + (VSYNC ? "ON" : "OFF");
        String exit = "Exit";

        font.setColor(options_selection == 0 ? Color.YELLOW : Color.WHITE);
        draw_centered((options_selection == 0 ? "> " : "") + fullscreen,
            Gdx.graphics.getHeight() * 0.60f);

        font.setColor(options_selection == 1 ? Color.YELLOW : Color.WHITE);
        draw_centered((options_selection == 1 ? "> " : "") + vsync,
            Gdx.graphics.getHeight() * 0.48f);

        font.setColor(options_selection == 2 ? Color.YELLOW : Color.WHITE);
        draw_centered((options_selection == 2 ? "> " : "") + exit,
            Gdx.graphics.getHeight() * 0.24f);

        batch.end();
    }
    private void draw_centered(String text, float y) {
        GlyphLayout layout = new GlyphLayout();
        layout.setText(font, text);

        float x = (Gdx.graphics.getWidth() - layout.width) / 2f;

        font.draw(batch, layout, x, y);
    }

    @Override
    public void dispose() {
        batch.dispose();
        font.dispose();
    }
}