package io.github.some_example_name;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.graphics.GL20;

//Henry

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. Listens to user input. */
public class Main extends InputAdapter implements ApplicationListener {
    public static gamestate GameState = gamestate.TITLE_SCREEN;
    public Renderer renderer;
    public Input input;
    public Title title;
    public Player player;
    public Rounds rounds;
    public Inventory inventory;
    public Goose goose;
    public static boolean debug = true;
    
    @Override
    public void create() {
        title = new Title();
        inventory = new Inventory();
        goose = new Goose(100, 100);
        player = new Player(inventory, goose);
        rounds = new Rounds();
        renderer = new Renderer(title, player, rounds, inventory, goose);
        input = new Input(renderer, title, player, inventory);
        
        Gdx.input.setInputProcessor(input);
    }

    @Override
    public void resize(int width, int height) {
        // If the window is minimized on a desktop (LWJGL3) platform, width and height are 0, which causes problems.
        // In that case, we don't resize anything, and wait for the window to be a normal size before updating.
        if(width <= 0 || height <= 0) return;
        renderer.resize_window(width, height);
    }

    @Override
    public void render() {
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        switch (GameState) {
            case TITLE_SCREEN:
                renderer.render_title();
                break;
            case OPTIONS:
                renderer.render_options();
                break;
            case GAMEPLAY:
                float delta = Gdx.graphics.getDeltaTime();
                title.timer -= delta;
                
                player.update(delta);
                goose.update(delta, player.x, player.y);

                renderer.render_background();
                renderer.render_player();
                renderer.render_goose();
                renderer.render_timer();
                if (debug)  {
                    renderer.render_debug();
                };
                renderer.render_inventory();
                break;
            default:
                break;
        }
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {
    }

    

    // Note: you can override methods from InputAdapter API to handle user's input.
}