package io.github.some_example_name;

public enum gamestate {
    TITLE_SCREEN,
    GAMEPLAY,
    PAUSE,
    OPTIONS
}


