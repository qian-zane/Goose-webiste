package io.github.some_example_name;

public class Rounds {
    public int round = 1;
    
}
